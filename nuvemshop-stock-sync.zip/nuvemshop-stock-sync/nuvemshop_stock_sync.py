#!/usr/bin/env python3
"""
nuvemshop_stock_sync.py
------------------------
Sincroniza a disponibilidade de produtos de terceiros (Dr. Martens, Timberland etc.)
cadastrados manualmente na Nuvemshop, checando se o produto ainda esta disponivel
no site oficial da marca.

Como funciona (fluxo geral):
1. Busca todos os produtos ATIVOS da loja via API da Nuvemshop.
2. Para cada produto, tenta identificar a marca a partir do TITULO (usando o
   dicionario "brands" do config.json).
3. Faz uma busca no site da marca usando o titulo do produto.
4. Compara o titulo do resultado mais parecido com o titulo do seu produto
   (similaridade de texto) para confirmar que e o mesmo item.
5. Se nao encontrar nada parecido, OU encontrar mas estiver marcado como
   esgotado, o produto e DESATIVADO (published=false) na Nuvemshop.
6. Loga tudo em arquivo + console, e nunca derruba a execucao inteira por
   causa de erro em um produto so (try/except por item).

Requisitos: ver requirements.txt
Configuracao: ver config.json (mesma pasta)

IMPORTANTE:
- Deixe "dry_run": true no config.json enquanto estiver testando. Nesse modo
  o script mostra o que FARIA, mas nao altera nada na loja.
- Como a correspondencia e feita por similaridade de titulo (nao por SKU/link
  exato), ela e uma HEURISTICA. Revise o log das primeiras execucoes antes de
  confiar 100% no modo automatico (dry_run=false).
"""

import json
import logging
import os
import re
import sys
import time
import unicodedata
from difflib import SequenceMatcher
from urllib.parse import quote_plus

import requests
from bs4 import BeautifulSoup

# --------------------------------------------------------------------------
# Configuracao / constantes
# --------------------------------------------------------------------------

CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
NUVEMSHOP_API_BASE = "https://api.nuvemshop.com.br/v1"


def load_config(path: str = CONFIG_PATH) -> dict:
    """Carrega o config.json e permite sobrescrever credenciais via variaveis
    de ambiente (recomendado ao rodar no GitHub Actions / PythonAnywhere,
    para nao deixar token gravado em texto no repositorio)."""
    with open(path, "r", encoding="utf-8") as f:
        config = json.load(f)

    # Variaveis de ambiente tem prioridade sobre o config.json
    env_store_id = os.environ.get("NUVEMSHOP_STORE_ID")
    env_token = os.environ.get("NUVEMSHOP_ACCESS_TOKEN")
    if env_store_id:
        config["nuvemshop"]["store_id"] = env_store_id
    if env_token:
        config["nuvemshop"]["access_token"] = env_token

    return config


def setup_logging(log_file: str) -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


# --------------------------------------------------------------------------
# Utilitarios de texto
# --------------------------------------------------------------------------

def normalize_text(text: str) -> str:
    """Remove acentos, baixa a caixa e limpa espacos extras, para comparacoes
    de texto mais confiaveis entre PT/EN e sites diferentes."""
    if not text:
        return ""
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"\s+", " ", text).strip().lower()
    return text


def title_similarity(title_a: str, title_b: str) -> float:
    """Retorna um score de 0 a 1 de o quanto dois titulos sao parecidos."""
    return SequenceMatcher(None, normalize_text(title_a), normalize_text(title_b)).ratio()


def detect_brand(product_title: str, brands_config: dict):
    """Tenta achar a marca de um produto procurando o nome da marca dentro
    do titulo. Retorna (chave_da_marca, config_da_marca) ou (None, None)."""
    normalized_title = normalize_text(product_title)
    for brand_key, brand_cfg in brands_config.items():
        if normalize_text(brand_key) in normalized_title:
            return brand_key, brand_cfg
    return None, None


# --------------------------------------------------------------------------
# Cliente da API Nuvemshop
# --------------------------------------------------------------------------

class NuvemshopClient:
    def __init__(self, store_id: str, access_token: str, user_agent: str, timeout: int = 15):
        self.store_id = store_id
        self.timeout = timeout
        self.base_url = f"{NUVEMSHOP_API_BASE}/{store_id}"
        self.headers = {
            "Authentication": f"bearer {access_token}",
            "Content-Type": "application/json",
            "User-Agent": user_agent,
        }

    def get_active_products(self) -> list:
        """Busca todos os produtos publicados, paginando automaticamente."""
        products = []
        page = 1
        per_page = 200
        while True:
            url = f"{self.base_url}/products"
            params = {"published": "true", "page": page, "per_page": per_page}
            try:
                resp = requests.get(url, headers=self.headers, params=params, timeout=self.timeout)
                resp.raise_for_status()
            except requests.RequestException as e:
                logging.error("Falha ao buscar produtos da Nuvemshop (pagina %s): %s", page, e)
                break

            batch = resp.json()
            if not batch:
                break
            products.extend(batch)
            if len(batch) < per_page:
                break
            page += 1
            time.sleep(0.5)  # respeita rate limit da API

        logging.info("Total de produtos ativos encontrados na Nuvemshop: %d", len(products))
        return products

    def set_product_published(self, product_id: int, published: bool) -> bool:
        """Ativa/desativa um produto na loja. Retorna True se deu certo."""
        url = f"{self.base_url}/products/{product_id}"
        payload = {"published": published}
        try:
            resp = requests.put(url, headers=self.headers, json=payload, timeout=self.timeout)
            resp.raise_for_status()
            return True
        except requests.RequestException as e:
            logging.error("Falha ao atualizar produto %s na Nuvemshop: %s", product_id, e)
            return False


# --------------------------------------------------------------------------
# Checagem no site do fornecedor
# --------------------------------------------------------------------------

def fetch_html(url: str, timeout: int, user_agent: str):
    """Busca uma URL e devolve (status_code, BeautifulSoup ou None).
    Nunca levanta excecao para fora - qualquer problema vira log + None."""
    headers = {"User-Agent": user_agent or "Mozilla/5.0 (compatible; StockSyncBot/1.0)"}
    try:
        resp = requests.get(url, headers=headers, timeout=timeout)
    except requests.RequestException as e:
        logging.warning("Erro de rede ao acessar %s: %s", url, e)
        return None, None

    if resp.status_code == 404:
        return 404, None

    if resp.status_code >= 400:
        logging.warning("Site retornou status %s para %s", resp.status_code, url)
        return resp.status_code, None

    try:
        soup = BeautifulSoup(resp.text, "html.parser")
    except Exception as e:  # protege contra HTML malformado / mudanca de estrutura
        logging.warning("Erro ao interpretar HTML de %s: %s", url, e)
        return resp.status_code, None

    return resp.status_code, soup


def search_brand_site(product_title: str, brand_cfg: dict, settings: dict, user_agent: str):
    """Pesquisa o titulo do produto no site da marca e retorna o melhor
    resultado encontrado como dict: {"title": str, "url": str, "similarity": float}
    ou None se nada relevante foi encontrado."""

    search_url = brand_cfg["search_url_template"].format(query=quote_plus(product_title))
    status, soup = fetch_html(search_url, settings["request_timeout_seconds"], user_agent)

    if soup is None:
        logging.warning("Nao foi possivel carregar a busca em %s (status=%s)", search_url, status)
        return None

    candidates = []

    # Tenta os seletores configurados especificamente para essa marca primeiro
    selectors = brand_cfg.get("product_link_selectors", [])
    for selector in selectors:
        try:
            for link in soup.select(selector):
                text = link.get_text(strip=True)
                href = link.get("href")
                if text and href:
                    candidates.append((text, href))
        except Exception as e:
            logging.debug("Seletor '%s' falhou em %s: %s", selector, search_url, e)

    # Fallback generico: qualquer link cujo texto pareca um nome de produto
    # (mais de 3 palavras, sem ser menu/rodape) - usado se os seletores
    # especificos nao acharem nada, por exemplo apos o site mudar de layout.
    if not candidates:
        for link in soup.find_all("a", href=True):
            text = link.get_text(strip=True)
            if text and len(text.split()) >= 3:
                candidates.append((text, link["href"]))

    if not candidates:
        return None

    # Escolhe o candidato mais parecido com o titulo do nosso produto
    best_text, best_href, best_score = None, None, 0.0
    for text, href in candidates:
        score = title_similarity(product_title, text)
        if score > best_score:
            best_text, best_href, best_score = text, href, score

    if best_text is None:
        return None

    return {"title": best_text, "url": best_href, "similarity": best_score}


def check_product_page_stock(url: str, brand_cfg: dict, settings: dict, user_agent: str):
    """Abre a pagina do produto encontrado e decide se esta em estoque.
    Retorna True (em estoque), False (esgotado/indisponivel) ou None
    (nao foi possivel determinar - trata-se com cautela pelo chamador)."""

    if not url.startswith("http"):
        # Sites costumam devolver links relativos; sem o dominio nao da pra checar
        logging.debug("URL de produto relativa e sem dominio, pulando checagem de pagina: %s", url)
        return None

    status, soup = fetch_html(url, settings["request_timeout_seconds"], user_agent)

    if status == 404:
        return False  # pagina sumiu = produto nao existe mais

    if soup is None:
        return None  # erro de rede/parse - nao decide nada com base nisso

    page_text = normalize_text(soup.get_text(" "))

    out_of_stock_keywords = [normalize_text(k) for k in brand_cfg.get("out_of_stock_keywords", [])]
    buy_keywords = [normalize_text(k) for k in brand_cfg.get("buy_button_keywords", [])]

    has_out_of_stock_text = any(k in page_text for k in out_of_stock_keywords)
    has_buy_button = any(k in page_text for k in buy_keywords)

    if has_out_of_stock_text and not has_buy_button:
        return False
    if has_buy_button and not has_out_of_stock_text:
        return True

    # Sinal ambiguo (achou os dois, ou nenhum dos dois) - nao decide sozinho,
    # melhor deixar para revisao manual do que desativar por engano.
    return None


# --------------------------------------------------------------------------
# Fluxo principal
# --------------------------------------------------------------------------

def process_product(product: dict, brands_config: dict, settings: dict, user_agent: str, client: NuvemshopClient):
    product_id = product.get("id")
    # Titulo pode vir em varios idiomas: pega o primeiro disponivel (pt preferencial)
    name_field = product.get("name", {})
    product_title = name_field.get("pt") or name_field.get("es") or name_field.get("en") or ""
    product_title = product_title.strip()

    if not product_title:
        logging.warning("Produto %s sem titulo legivel, pulando.", product_id)
        return

    brand_key, brand_cfg = detect_brand(product_title, brands_config)
    if not brand_cfg:
        logging.info("[%s] '%s' - marca nao mapeada no config.json, pulando (mapeie manualmente se necessario).",
                     product_id, product_title)
        return

    logging.info("[%s] '%s' -> marca identificada: %s", product_id, product_title, brand_cfg["display_name"])

    try:
        result = search_brand_site(product_title, brand_cfg, settings, user_agent)
    except Exception as e:
        # Rede caiu, site mudou de estrutura, etc. Nunca deixa isso derrubar o script.
        logging.error("[%s] Erro inesperado buscando no site da marca: %s", product_id, e)
        return

    min_similarity = settings.get("min_title_similarity", 0.6)

    if result is None or result["similarity"] < min_similarity:
        # Nao achamos nada parecido o suficiente -> tratamos como indisponivel
        found_desc = f"(melhor match: '{result['title']}' score={result['similarity']:.2f})" if result else "(nenhum resultado)"
        logging.info("[%s] Nao encontrado no site da marca %s -> desativar. %s",
                     product_id, brand_cfg["display_name"], found_desc)
        deactivate_product(product_id, product_title, settings, client)
        return

    logging.info("[%s] Encontrado: '%s' (similaridade=%.2f) -> %s",
                 product_id, result["title"], result["similarity"], result["url"])

    try:
        in_stock = check_product_page_stock(result["url"], brand_cfg, settings, user_agent)
    except Exception as e:
        logging.error("[%s] Erro inesperado checando estoque na pagina do produto: %s", product_id, e)
        return

    if in_stock is False:
        logging.info("[%s] Marcado como ESGOTADO no site da marca -> desativar.", product_id)
        deactivate_product(product_id, product_title, settings, client)
    elif in_stock is True:
        logging.info("[%s] Disponivel no site da marca.", product_id)
        if settings.get("auto_reenable_if_back_in_stock") and not product.get("published", True):
            reactivate_product(product_id, product_title, settings, client)
    else:
        logging.info("[%s] Nao foi possivel confirmar o status de estoque com certeza - "
                     "nenhuma acao tomada (revise manualmente).", product_id)


def deactivate_product(product_id: int, product_title: str, settings: dict, client: NuvemshopClient):
    if settings.get("dry_run", True):
        logging.info("[DRY-RUN] Desativaria o produto %s ('%s') na Nuvemshop.", product_id, product_title)
        return
    ok = client.set_product_published(product_id, False)
    if ok:
        logging.info("Produto %s ('%s') DESATIVADO na Nuvemshop.", product_id, product_title)


def reactivate_product(product_id: int, product_title: str, settings: dict, client: NuvemshopClient):
    if settings.get("dry_run", True):
        logging.info("[DRY-RUN] Reativaria o produto %s ('%s') na Nuvemshop.", product_id, product_title)
        return
    ok = client.set_product_published(product_id, True)
    if ok:
        logging.info("Produto %s ('%s') REATIVADO na Nuvemshop.", product_id, product_title)


def main():
    config = load_config()
    settings = config["settings"]
    setup_logging(settings.get("log_file", "stock_sync.log"))

    logging.info("=== Iniciando sincronizacao de estoque (dry_run=%s) ===", settings.get("dry_run", True))

    store_id = config["nuvemshop"]["store_id"]
    access_token = config["nuvemshop"]["access_token"]
    user_agent = config["nuvemshop"].get("user_agent", "StockSyncBot/1.0")

    if not store_id or "SEU_" in str(store_id) or not access_token or "SEU_" in str(access_token):
        logging.error("Credenciais da Nuvemshop nao configuradas. Preencha config.json ou defina as "
                       "variaveis de ambiente NUVEMSHOP_STORE_ID e NUVEMSHOP_ACCESS_TOKEN.")
        sys.exit(1)

    client = NuvemshopClient(store_id, access_token, user_agent, settings.get("request_timeout_seconds", 15))
    products = client.get_active_products()

    if not products:
        logging.warning("Nenhum produto ativo retornado pela API. Encerrando.")
        return

    for product in products:
        try:
            process_product(product, config["brands"], settings, user_agent, client)
        except Exception as e:
            # Ultima linha de defesa: um produto com problema nunca para os demais.
            logging.error("Erro nao tratado processando produto %s: %s", product.get("id"), e)
        time.sleep(settings.get("delay_between_requests_seconds", 2))

    logging.info("=== Sincronizacao concluida ===")


if __name__ == "__main__":
    main()
